# Corrección de actualización automática y estado

Reemplazá en GitHub estos archivos:
- `public/app.js`
- `public/index.html`

No hace falta reemplazar `server.js`, `package.json`, las variables de entorno ni el script Python.

Cambios:
- La página consulta el historial cada 10 segundos (los informes pueden llegar cada 2 minutos).
- La consulta incluye un parámetro variable para evitar respuestas cacheadas.
- La posición de lectura se conserva al insertar informes nuevos arriba.
- El botón indica la dirección correcta: flecha hacia arriba.
- Si pasan 5 minutos sin un informe nuevo, el estado cambia de “En vivo” a “Sin actividad reciente”.
- Se cambia la versión de los archivos estáticos para evitar que el navegador siga usando JavaScript anterior.

El estado es una inferencia basada en la hora del último informe: el sitio web no puede comprobar directamente si PowerShell sigue abierto en tu PC.
